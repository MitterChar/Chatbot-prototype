import tkinter as tk

def create_window():
    window = tk.Tk()
    window.overrideredirect(True)  # This will create a borderless window
    window.geometry("75x18+540+197")  # Here you can specify the size and the position of the window

    window.configure(background='#F3F3F3')  # This will change the background color

    window.attributes('-topmost', 1)  # This will keep the window always on top

    window.mainloop()

create_window()
