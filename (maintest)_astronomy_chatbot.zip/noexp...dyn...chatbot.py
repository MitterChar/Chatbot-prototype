import gradio as gr
import time
import random
import math
import re
import nltk
from nltk.corpus import cmudict
nltk.download('cmudict')
nltk.download('punkt')


import json
def conversation_flow():
    with open('chat_data.json', 'r') as f:
        data = json.load(f)

    return data['questions'], data['responses']

question_list, response_list = conversation_flow()
questions = question_list.copy()
conversation_len = len(questions) - 1


d = cmudict.dict()

def nsyl(word):
    return [len(list(y for y in x if y[-1].isdigit())) for x in d[word.lower()]]

def calculate_dmsent(text):
    total_sentences = 1
    total_words = len(text.split(" "))
    total_syllables = sum(nsyl(word)[0] for word in text.split(" ") if word.lower() in d)

    # calculate C(m)
    Cm = 0.39 * (total_words / total_sentences) + 11.8 * (total_syllables / total_words) - 15.59

    # calculate D(m)
    if Cm > 0:
        Dm = 0.2 * math.log(Cm + 0.5) + 0.5
    else:
        Dm = 0

    return Dm

def calculate_dm(text):
    sentences = re.split(r'[.!?]', text)
    total_delay = 0

    for sentence in sentences:
        sentence_delay = calculate_dmsent(sentence)
        total_delay += sentence_delay

    return total_delay



with open("custom.css", "r", encoding="utf-8") as f:
    customCSS = f.read()


history = []
i = 0


with gr.Blocks(css=customCSS, theme=gr.themes.Glass()) as block:
    gr.Markdown("""<h1 style="font size: 20px;"><center>Astronomy Chatbot</center></h1>""")
    chatbot = gr.Chatbot(elem_id="chuanhu_chatbot").style(height="50%")
    message = gr.Textbox(lines=1, placeholder="Message here...", timer=False)
    state = gr.State()
    submit = gr.Button("SEND")
    auto_question = gr.Button("Provide a question.")
    clear = gr.Button("CLEAR")

    def chatbot_input_printing(input, output):
        global history
        global i

        history.append([input, None])

        if input in question_list:
            i = question_list.index(input)
        return history, history


    def chatbot_explanation(input, output):
        global history
        global i

        time.sleep(0.1)

        if i == 0 or i == conversation_len:
            history.append([None, None])

        else:
            explanation = '<i><span style="font-size: 13px; color:#999999;">I am using your question as a prompt to generate the answer from my latest AI model.</span></i>'
            
            history.append([None, explanation])
        return history, history


    def chatbot_response(input, output):
        global history
        global i

        global question_list
        response_delay = 0
        response = ""

        sleep_time = random.uniform(0.2, 0.4)  #time delay caused by physical factors of internet
        time.sleep(sleep_time)

        if input in question_list:
            if i == 0 or i == conversation_len:
                response = response_list[i]
            else:
                response = '<i><b><span style="font-size: 13px;">Answer:</span></b></i>'+' '+response_list[i]
        else:
            response = "Nothing out from there, please provide me the right question."

        
            
        response_delay = calculate_dm(response_list[i])
        #response_delay = delay_count(response_list[i])
        time.sleep(response_delay)
        
        history.append([None, response])
        return history, history



    def delay_count(response):
        #calculate the delay time for response
        character_count = len(response)
        delay_count = character_count * 0.03
        return delay_count
    

    def chatbot_reset(input, output):
        global history
        history = []

        return history, history


    def chose_question():
        global questions, question_list
        question = random.choice(questions)
        questions.remove(question)
        if not questions:
            questions = question_list.copy()

        return question

    message.submit(chatbot_input_printing, inputs=[message, state], outputs=[chatbot, state])
    #message.submit(chatbot_explanation, inputs=[message, state], outputs=[chatbot, state])
    #message.submit(chatbot_loading, inputs=[message,state], outputs=[chatbot, state])
    #message.submit(chatbot_loadending, inputs=[message,state], outputs=[chatbot, state])
    message.submit(chatbot_response, inputs=[message, state], outputs=[chatbot, state])
    message.submit(lambda x: gr.update(value=''), [], [message])

    submit.click(chatbot_input_printing, inputs=[message, state], outputs=[chatbot, state])
    #submit.click(chatbot_explanation, inputs=[message, state], outputs=[chatbot, state])
    #submit.click(chatbot_loading, inputs=[message,state], outputs=[chatbot, state])
    #submit.click(chatbot_loadending, inputs=[message,state], outputs=[chatbot, state])
    submit.click(chatbot_response, inputs=[message, state], outputs=[chatbot, state])
    submit.click(lambda x: gr.update(value=''), [], [message])

    auto_question.click(lambda x: gr.update(value=chose_question()), [], [message])

    clear.click(chatbot_reset, inputs=[message, state], outputs=[chatbot, state])

block.launch(debug=True)
