import gradio as gr
import time
import random



import json
def conversation_flow():
    with open('chat_data.json', 'r') as f:
        data = json.load(f)

    return data['questions'], data['responses']

question_list, response_list = conversation_flow()
questions = question_list.copy()
conversation_len = len(questions) - 1


with open("custom.css", "r", encoding="utf-8") as f:
    customCSS = f.read()



history = []
i = 0


with gr.Blocks(css=customCSS, theme=gr.themes.Glass()) as block:
    gr.Markdown("""<h1 style="font size: 20px;"><center>Astronomy Chatbot</center></h1>""")
    chatbot = gr.Chatbot(elem_id="chuanhu_chatbot").style(height="50%")
            
    message = gr.Textbox(lines=1, placeholder="Message here...", timer=False, value = "",elem_id="textbox")
    state = gr.State()
    submit = gr.Button("SEND")
    auto_question = gr.Button("Provide a question.")
    clear = gr.Button("CLEAR")

    def chatbot_input_printing(input, output):
        global history
        global i

        history.append([input, None])

        if input in question_list:
            i = question_list.index(input)
        return history, history

    
    def chatbot_response(input, output):
        global history
        global i

        global question_list
        response_delay = 0
        response = ""

        sleep_time = random.uniform(0.2, 0.4)  #time delay caused by physical factors of internet
        time.sleep(sleep_time)

        if input in question_list:
            if i == 0 or i == conversation_len:
                response = response_list[i]
            else:
                #response = '<u><i><b><span style="font-size: 13px;">Chatbot Response:</span></b></i></u>'+' '+response_list[i]
                #response = '<i><b><span style="font-size: 13px;">Chatbot Response:</span></b></i>'+' '+response_list[i]
                response = '<i><b><span style="font-size: 13px;">Answer:</span></b></i>'+' '+response_list[i]
        else:
            response = "Nothing out from there, please provide me the right question."

        history.append([None, response])
        return history, history

    def chatbot_explanation(input, output):
        global history
        global i

        time.sleep(0.1)

        if i == 0 or i == conversation_len:
            history.append([None, None])
        else:
            #explanation = '''<u><i><b><span style="font-size: 13px;">Chatbot Status:</span></b></i></u><span style="font-size: 13px;"> I am searching for the answer that matches your question intent most in my knowledge base.</span>'''
            #explanation = '''<u><i><b><span style="font-size: 13px;">Chatbot Status:</span></b></i></u> <i><span style="font-size: 13px;"> I am using your question as a prompt to generate the answer from my latest AI model.</i></span>'''
            #explanation = '<u><b><span style="font-size: 13px; background-color:#f1d1d1;">Chatbot Status:</span></b></u>'+'<i><span style="font-size: 13px; background-color:#f1d1d1;"> I am using your question as a prompt to generate the answer from my latest AI model.</span></i>'
            #explanation = '<b><i><span style="font-size: 13px; color:#737070;">Chatbot Status:</span></i></b>'+'<i><span style="font-size: 13px; color:#737070;"> I am using your question as a prompt to generate the answer from my latest AI model.</span></i>'
            #explanation = '<i><span style="font-size: 13px; color:#737070;">I am using your question as a prompt to generate the answer from my latest AI model.</span></i>'
            #explanation = '<i><span style="font-size: 13px; color:#737070;">I am using your question as a prompt to generate the answer from my latest AI model.</span></i>'
            #explanation = '<i><span style="font-size: 13px; color:#999999;">I am using your question as a </span></i>'+'<i><span style="font-size: 13px;">prompt<span></i>'+'<i><span style="font-size: 13px; color:#999999;"> to generate the answer from my </span></i>'+'<i><span style="font-size: 13px;">latest AI model.</span></i>'
            explanation = '<i><span style="font-size: 13px; color:#999999;">I am searching for the answer that matches your question intent most in my knowledge base.</span></i>'

            history.append([None, explanation])
        return history, history

    def chatbot_reset(input, output):
        global history
        history = []

        return history, history

    def chose_question():
        global questions, question_list
        question = random.choice(questions)
        questions.remove(question)
        if not questions:
            questions = question_list.copy()

        return question



    
    message.submit(chatbot_input_printing, inputs=[message, state], outputs=[chatbot, state])
    message.submit(chatbot_explanation, inputs=[message, state], outputs=[chatbot, state])
    #message.submit(chatbot_loading, inputs=[message,state], outputs=[chatbot, state])
    #message.submit(chatbot_loadending, inputs=[message,state], outputs=[chatbot, state])
    message.submit(chatbot_response, inputs=[message, state], outputs=[chatbot, state])
    message.submit(lambda x: gr.update(value=""), [], [message])

    submit.click(chatbot_input_printing, inputs=[message, state], outputs=[chatbot, state])
    submit.click(chatbot_explanation, inputs=[message, state], outputs=[chatbot, state])
    #submit.click(chatbot_loading, inputs=[message,state], outputs=[chatbot, state])
    #submit.click(chatbot_loadending, inputs=[message,state], outputs=[chatbot, state])
    submit.click(chatbot_response, inputs=[message, state], outputs=[chatbot, state])
    submit.click(lambda x: gr.update(value=''), [], [message])

    auto_question.click(lambda x: gr.update(value=chose_question()), [], [message])

    clear.click(chatbot_reset, inputs=[message, state], outputs=[chatbot, state])

block.launch(debug=True)