from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import random
import math
import re
import nltk
from nltk.corpus import cmudict
nltk.download('cmudict')
nltk.download('punkt')


d = cmudict.dict()

def nsyl(word):
    return [len(list(y for y in x if y[-1].isdigit())) for x in d[word.lower()]]

def calculate_dmsent(text):
    total_sentences = 1
    total_words = len(text.split(" "))
    total_syllables = sum(nsyl(word)[0] for word in text.split(" ") if word.lower() in d)

    # calculate C(m)
    Cm = 0.39 * (total_words / total_sentences) + 11.8 * (total_syllables / total_words) - 15.59

    # calculate D(m)
    if Cm > 0:
        Dm = 0.2 * math.log(Cm + 0.5) + 0.5
    else:
        Dm = 0

    return Dm

def calculate_dm(text):
    sentences = re.split(r'[.!?]', text)
    total_delay = 0

    for sentence in sentences:
        sentence_delay = calculate_dmsent(sentence)
        total_delay += sentence_delay

    return total_delay


import json
def conversation_flow():
    with open('chat_data.json', 'r') as f:
        data = json.load(f)

    return data['questions'], data['responses']

question_list, response_list = conversation_flow()

for response in response_list:
    print(calculate_dm(response))
