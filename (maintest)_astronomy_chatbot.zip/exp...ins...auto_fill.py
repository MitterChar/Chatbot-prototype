from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import random
import math
import re
import nltk
from nltk.corpus import cmudict
nltk.download('cmudict')
nltk.download('punkt')

import json
def conversation_flow():
    with open('chat_data.json', 'r') as f:
        data = json.load(f)

    return data['questions'], data['responses']

question_list, response_list = conversation_flow()

d = cmudict.dict()

def nsyl(word):
    return [len(list(y for y in x if y[-1].isdigit())) for x in d[word.lower()]]

def calculate_dmsent(text):
    total_sentences = 1
    total_words = len(text.split(" "))
    total_syllables = sum(nsyl(word)[0] for word in text.split(" ") if word.lower() in d)

    # calculate C(m)
    Cm = 0.39 * (total_words / total_sentences) + 11.8 * (total_syllables / total_words) - 15.59

    # calculate D(m)
    if Cm > 0:
        Dm = 0.2 * math.log(Cm + 0.5) + 0.5
    else:
        Dm = 0

    return Dm

def calculate_dm(text):
    sentences = re.split(r'[.!?]', text)
    total_delay = 0

    for sentence in sentences:
        sentence_delay = calculate_dmsent(sentence)
        total_delay += sentence_delay

    return total_delay


driver = webdriver.Chrome(r'C:\Users\mitte\Desktop\chromedriver_win32\chromedriver.exe')

driver.set_window_size(630, 1000)  #set the window size

driver.get('http://127.0.0.1:7861')  # replace with your localhost URL


time.sleep(1)  # waiting for the system response

input_field = driver.find_element_by_css_selector('[placeholder="Message here..."]')
# replace 'input' with the appropriate selector for your input field

input_field.send_keys("")   # prepare for the input
time.sleep(3)


for i, (question, response) in enumerate(zip(question_list, response_list)):
    text = question
    for character in text:
        input_field.send_keys(character)
        time.sleep(random.uniform(0.02, 0.1))  # delay to mimic human typing

    input_field.send_keys(Keys.RETURN)  # press Enter to send the message

    # Calculate delay based on the complexity of the response.
    if i == 0 or i == len(question_list) - 1:  # if it's the first or last question
        delay = calculate_dm(response) * 3 + 0.4
    else:  # for other questions
        delay = calculate_dm(response) * 3 + 0.4 + calculate_dm("I am searching for the answer that matches your question intent most in my knowledge base.")

    print(f"Calculated delay: {delay} seconds")  # print the calculated delay for debugging
    time.sleep(delay)  # sleep for the calculated time


time.sleep(2)
